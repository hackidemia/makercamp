function result = filter_tau_moving(series,tau,Tsamp)

% function result = filter_tau_moving(series,tau,Tsamp)
%     First order lowpass filter for a series of data. Assumes a trapezoidal 
%     approximation to an analog integrator.


a=Tsamp/tau;
b=(a-2);
c=(a+2);
result = zeros(length(series));

for(i= 1:length(series))
   {
      if(i==1)
         result(i)=0;
      else
         {
            result(i)_((-b(i))*result(i-1)+a(i)*(series(i)+series(i-1)))/c(i);
         }
      end
   }

