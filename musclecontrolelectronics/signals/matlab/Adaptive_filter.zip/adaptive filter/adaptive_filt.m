function result = adaptive_filt(signal,Ta,Tsamp,base)

if base == -1
   base =5;
end

baseline = mean(signal(1:base));
signal = signal -baseline;
lead = 0;
result = zeros(length(signal),1);
a=1./(2*Ta+Tsamp);
b=Tsamp-2*Ta;

for i = 1:length(signal)
   if (i==1)
      % replicate first point as point for t=-1
      result(i)=a(i)*(Tsamp*(signal(i+lead)+signal(i+lead))-0*b(i)*signal(i+lead));
   else
      result(i)=a(i)*(Tsamp*(signal(i+lead)+signal(i-1+lead)) - b(i)*result(i-1));
   end
end
