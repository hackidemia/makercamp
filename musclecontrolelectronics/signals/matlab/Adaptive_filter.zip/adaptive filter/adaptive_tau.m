function result = adaptive_tau(smooth_diff,TauL,TauS,a)

%function result = adaptive.tau(smooth.diff,TauL,TauS,a) {
%  returns  a vector of time constants for an adaptive filter
%  "smooth.diff" is the smoothed difference vector for the 
%  signal to be adaptively filtered.

result=(TauL + 100*a*TauS.*smooth_diff)./(1+100*a.*smooth_diff);
ind = find(result < 0.1);
result(ind) = 0.1;
   

