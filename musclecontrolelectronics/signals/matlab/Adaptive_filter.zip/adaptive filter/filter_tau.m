function result = filter_tau(series,tau,Tsamp,base)

% function result = filter_tau(series,tau,Tsamp)
%     First order lowpass filter for a series of data. Assumes a trapezoidal 
%     approximation to an analog integrator.

if base == -1
   base = 5;
end

a=Tsamp/tau;
b=(a-2);
c=(a+2);
result = zeros(length(series),1);
baseline = mean(series(1:base));

for i = 1:length(series)
   if(i==1)
      result(i) = baseline;
   else
      result(i)=((-b).*result(i-1)+a.*(series(i)+series(i-1)))./c;
   end   
end
