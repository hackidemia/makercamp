function Y = musc_adaptive_filter(signal,TauL,TauS,a,Tsamp,base)

%function Y = musc.adaptive.filter(signal,TauL,TauS,a,Tsamp,base)
%  Adaptively filter an emg signal.  The flow of control is as follows
%  1.  pre filter using a second order parrallel filter with tau = 50ms
%  2.  difference the resulting signal with lag=10ms
%  3.  first order filter the square of the diff signal with tau=15ms
%  4.  normalize the resulting signal with respect to the peak difference
%  5.  compute the adaptive time constant from the resulting signal
%      using TauS and TauL
%  6.  first order filter the original signal with the adaptive time constant
%
%  All parameters to the function call need to be in milliseconds
%
%  Fairly good parameters (derived purely empirically) are TauL=100,
%  TauS=15, a=1.4
%
%  Returns a list(Y,pre-filtered signal,filtered-diff signal,Ta (adaptive tau)) if verbose=T
%  or else just return

if base == -1
   base = 5;
end
pre = pre_filt(signal,50,Tsamp,base);
Y = pre;
%return;
%	pre_signal
prediff=diff(pre);
prediff = [0 prediff'];
%filt_diff=filter_tau(prediff*prediff*prediff*prediff*prediff*prediff*prediff*prediff,15,Tsamp);
filt_diff = filter_tau(prediff.^2,15,Tsamp,base);
filt_diff = filt_diff/max(filt_diff);
Ta = adaptive_tau(filt_diff,TauL,TauS,a);
Y = adaptive_filt(signal,Ta,Tsamp,base);

