clear all;
clc

load amp_trials.mat;

load(amp_trials{1,1});
baseline = mean(data,1);
% get the baseline voltage when stimulated at 1V
baseline_VecSum = norm(baseline);
% get the vector sum of the baseline.

NofTrials = size(amp_trials,1);
for i = 1 : NofTrials
    load(amp_trials{i,1});
    filt_data = maf(data,25);  
    % use the moving average filter to smooth data. Set to take 25 points from each side.
    VecSum(:,i) = (filt_data(:,1).^2+filt_data(:,2).^2).^0.5;
    % get the vector sum of trial datas.
    amp_VecSum(:,i) = abs(VecSum(:,i)-baseline_VecSum);

    for j = 1 : 20
        AmpMax_VecSum(j,i) = max(amp_VecSum(500*(j-1)+1:500*j,i));
    end
end

figure,
plot(AmpMax_VecSum(:,2:end),'o--')
xlim([0 21])
xlabel('Response Counts')
ylabel('Response Amplitude (V)')
set(gca, 'box', 'off');

legend('2V','3V','4V','5V','6V','7V','8V')