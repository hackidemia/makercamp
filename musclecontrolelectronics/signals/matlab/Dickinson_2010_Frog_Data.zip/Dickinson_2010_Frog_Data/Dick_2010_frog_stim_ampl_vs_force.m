% % stim amplitude vs transducer voltage (frog force)

clear; clc; 
% close all;  % close all figures
clf;

load('amp_trials.mat');
% load('hz_trials.mat');
sample_rate = 1000;

pts_mv_avg = 25; % number of points in the moving average for smoothing data

mag_force = @(v1, v2) sqrt(v1.*v1+v2.*v2);
% smooth_data = @(voltage) filter(filter_mv_avg, norm_mv_avg, voltage);
smooth_data = @(voltage) maf(voltage, pts_mv_avg);

for i=1:length(amp_trials)
    load(amp_trials{i, 1}, 'data');
% get trial time in seconds -> trial samples/ sample_rate
    trial_time = (1:1:length(data))/sample_rate;
    
    data_x = data(:, 1);
    data_y = data(:, 2);
   
    if(i == 1)
       baseline =  smooth_data(mag_force(data_x, data_y));
%        continue;
    end
    
    force_tl = baseline-smooth_data(mag_force(data_x, data_y));
   
    eval(['data_x_' num2str(i) 'v = data_x;']);
    eval(['data_y_' num2str(i) 'v = data_y;']);
    eval(['force_tl_' num2str(i) 'v = force_tl;']);
end


% %  align phases of different trials to make 
% %     comparison viewing easier
graph_window = 2;  % number of seconds of stim response to view
% slide all plots
mass_offset = 250;
% offsets for individual plots to align them for comparison
offset2 =mass_offset + 80;
offset3 = mass_offset + 350;
offset4 = mass_offset + 940;
offset5 = mass_offset + 1400;
offset6 = mass_offset + 750;
offset7 = mass_offset + 110;
offset8 = mass_offset + 840;

plot( ...    
    trial_time(1:end-offset2), force_tl_2v(offset2+1:end), ...
    trial_time(1:end-offset3), force_tl_3v(offset3+1:end), ...
    trial_time(1:end-offset4), force_tl_4v(offset4+1:end), ...
    trial_time(1:end-offset5), force_tl_5v(offset5+1:end), ...
    trial_time(1:end-offset6), force_tl_6v(offset6+1:end), ...
    trial_time(1:end-offset7), force_tl_7v(offset7+1:end), ...
    trial_time(1:end-offset8), force_tl_8v(offset8+1:end) ...       
    );
    xlabel('Time (seconds)');
    ylabel('Force (V)');
% ylabel('Force (N)');
    legend( ...        
        '2V', ...
        '3V', ...
        '4V', ...
        '5V', ...
        '6V', ...
        '7V', ...
        '8V', ...
        'Location', ...
        'NorthEast');
    xlim([0 graph_window]);
%     ylim([-0.01 0.10]);
set(gca, 'box', 'off');




