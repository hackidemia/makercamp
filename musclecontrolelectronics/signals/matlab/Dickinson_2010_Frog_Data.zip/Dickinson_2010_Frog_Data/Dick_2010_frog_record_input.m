AI_SAMPLE_RATE= 1000;     % analog input sampling rate

% INTIALIZE ANALOG IN
ai = analoginput('mcc',0);    
% this input configuration is for the PCI DAS1200JR
% if you are using a different card, you might want to check that before
% you run this file.
set(ai,'InputType','SingleEnded')
% set(ai,'BufferingMode','Manual')   
% set(ai,'BufferingConfig',[8 109])
addchannel(ai, 1:2);     % acquire the first two channels  
set(ai, 'SampleRate', AI_SAMPLE_RATE);
set(ai, 'SamplesPerTrigger', inf);
set(ai.Channel(1),'SensorRange',[-5 5])
set(ai.Channel(1),'InputRange',[-5 5])
set(ai.Channel(1),'UnitsRange',[-5 5])
set(ai.Channel(2),'SensorRange',[-5 5])
set(ai.Channel(2),'InputRange',[-5 5])
set(ai.Channel(2),'UnitsRange',[-5 5])

start(ai)
data = getdata(ai,10*AI_SAMPLE_RATE);  % get 10s  of data
stop(ai)        % stop the AI
flushdata(ai)
delete(ai)

figure(1); clf;

plot(data_all)
title('Data')