Dickinson 2010 Frog Lab Data

Enclosed in this archive are the trial data (mat files) from our experiments and the MATLAB m-files used to generate the graphs seen in our lab report: (http://ediacaran.mech.northwestern.edu/neuromech/index.php/Frog_Lab_Spring_2010-_Dickinson#Results)

Dick_2010_frog_stim_ampl_vs_force.m:  creates the stimulus amplitude vs. force graph (Figure 5) in the lab report. To generate the graph , execute this m-file in the same directory as the data files. Requires maf.m and all .mat files in the same directory.

Dick_2010_frog_amp_trend.m: create the response amplitude trend graph (Figure 8) in the lab report. To generate the graph, execute this m-file in the same directory as the data files. Requires maf.m and all .mat files in the same directory.

Dick_2010_frog_record_input.m: record the data on the analog input (PCI DAS1200JR). To use this file, simply execute this m-file. You should save the workspace manually after you finish this m-file.

maf.m - an averaging function that smooths out data by taking the averaging out each point with an equal number of preceding and succeeding points

