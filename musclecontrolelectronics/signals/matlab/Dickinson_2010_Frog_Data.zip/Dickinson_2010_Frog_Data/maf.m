function fmean = maf(f,n)
% updated June 2010
% This function maf takes average "column by column".
% f = raw data
% n = number of points being included on each side (before and after).

% e.g. maf(f,50) will include 101 points for each target point 
% (50 points before + target point + 50 points after).

[flen,dlen] = size(f);

fmean = zeros(flen,dlen);
for j = 1 : dlen
    for i = 1 : flen
        if i < n+1
            fmean(i,j) = sum(f(1:2*i-1,j))/(2*i-1);
        elseif i > flen-n
            fmean(i,j) = sum(f(2*i-flen:flen,j))/(2*(flen-i)+1);
        else
            fmean(i,j) = sum(f(i-n:i+n,j))/(2*n+1);
        end
    end
end